=== Vafpress Portfolio ===
Contributors: vafpress
Donate link: http://vafpress.com
Tags: portfolio, vafpress
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 0.1-alpha
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Portfolio custom post types.

== Description ==

Portfolio custom post types.

== Installation ==

1. Upload plugin package file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Why is this page blank? =

No one asked anything yet :p

== Screenshots ==

1. All the things that you can customize via settings page.

== Changelog ==

= 0.1-alpha =
* Initial version

== Upgrade Notice ==

Not yet